



            <main class="main-wrapper col-md-9 ms-sm-auto py-4 col-lg-9 px-md-4 border-start">






                <style>
                    ul li {
                        color: #000;
                        font-size: var(--menu-font-size);
                        font-weight: var(--font-weight-normal);
                    }
                </style>

                <style>
                    /* Center modal */
                    .modal-dialog {
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        min-height: 100vh;
                    }

                    /* Modal Content Styling */
                    .modal-content {
                        text-align: center;
                        padding: 20px;
                        background: #fff;
                        border-radius: 10px;
                        color: #000;
                    }

                    /* Buttons */
                    .btn-custom {
                        background-color: #fe9f1b;
                        border: none;
                        padding: 10px 20px;
                        color: white;
                        font-size: 16px;
                        cursor: pointer;
                        width: 100%;
                        margin-top: 10px;
                    }

                    .btn-custom:hover {
                        background-color: #e68a00;
                    }

                    @media (min-width: 576px) {
                        .modal-dialog {
                            max-width: 100vh;
                        }
                    }
                </style>









                <div class="title-group mb-3">
                    <h1 class="h2 mb-0">Overview</h1>
                    <small class="text-muted">Hello <?= $application['name'] ?>, welcome back!</small>
                </div>

                <div class="row my-4">
                    <div class="col-lg-7 col-12">
                        <div class="custom-block custom-block-balance">
                            <small>Loan Amount</small>

                            <h2 class="mt-2 mb-3">₹ <?= number_format($application['loan_amount'], 2) ?></h2>

                            <div class="custom-block-numbers d-flex align-items-center">
                                <small style="margin-right: 10px;color: #000;">EMI</small>
                                <small style="color: #000;">₹ <?= number_format($application['loan_emi'], 2) ?></small>
                            </div>


                            <div class="d-flex">
                                <div>
                                    <small>Bank Account</small>
                                    <p><?= $application['bank_account'] ?></p>
                                </div>

                                <div class="ms-auto">
                                    <small>Bank Holder</small>
                                    <p><?= $application['bank_holder'] ?></p>
                                </div>
                            </div>
                        </div>



                        <!--<div class="custom-block bg-white">
                                <div id="chart"></div>
                            </div>-->

                        <div class="custom-block custom-block-exchange"
                            style=" font-family: sans-serif;background: #79554833; ">
                            <h5 class="mb-4">Loan Status</h5>
                            <!--approval-->
                            <h5 style="color: #000;">Approved Loan Amount</h5>
                            <p style="margin-top: 0;"><span style="color: #000;">This is Aadhaar Based Loan
                                    Approval</span></p>
                            <p style="margin-top: 0;"><span style="color: #000;">Loan Amount ₹ <?= number_format($application['loan_amount'], 2) ?></span></p>
                            <p style="margin-top: 0;"><span style="color: #000;">Tenure: <?= $application['period']; ?> Months</span></p>
                            <p style="margin-top: 0;"><span style="color: #000;">ROI Per Annum: <?=  $application['interest']; ?>%</span></p>
                            <p style="margin-top: 0;"><span style="color: #000;">EMI: ₹ <?= number_format($application['loan_emi'], 2) ?></span></p>
                            <br>
                            <button class="btn btn-custom mb-2" data-bs-toggle="modal"
                                data-bs-target="#exampleModalLong">Withdraw Your Loan Amount</button>

                        </div>
























                        <div class="custom-block bg-white">
                            <h5 class="mb-4">Loan Overview</h5>

                            <div id="pie-chart"></div>
                        </div>


                    </div>

                    <div class="col-lg-5 col-12">
                        <div class="custom-block custom-block-profile-front custom-block-profile text-center bg-white">
                            <div class="custom-block-profile-image-wrap mb-4">
                                <img src="<?php echo base_url('fronted'); ?>/website/customer/images/medium-shot-happy-man-smiling.jpg"
                                    class="custom-block-profile-image img-fluid" alt="">

                                <a href="<?php echo base_url('home/setting'); ?>" class="bi-pencil-square custom-block-edit-icon"></a>
                            </div>

                            <p class="d-flex flex-wrap mb-2">
                                <strong>Name :</strong>

                                <span><?= $application['name'] ?></span>
                            </p>

                            <p class="d-flex flex-wrap mb-2">
                                <strong>Email :</strong>

                                <span>
                                    <?= $application['email'] ?>
                                </span>
                            </p>

                            <p class="d-flex flex-wrap mb-0">
                                <strong>Mobile :</strong>

                                <span>
                                    <?= $application['mobile'] ?>
                                </span>
                            </p>
                        </div>



                        <div class="custom-block custom-block-transations">
                            <h5 class="mb-4">Recent Transations</h5>

                            <div class="border-top pt-4 mt-4 text-center">


                                <p class="text-danger">Not found any transaction</p>


                                <!--Agreement-->


                                <!--holding-->



                                <!--insurance-->



                                <!--noc-->


                                <div class="border-top pt-4 mt-4 text-center">
                                    <a class="btn custom-btn" href="user/transactions">
                                        View all transations
                                        <i class="bi-arrow-up-right-circle-fill ms-2"></i>
                                    </a>
                                </div>
                            </div>
                        </div>




                        <!--<div class="custom-block primary-bg">
                            <h5 class="text-white mb-4">Re-Payment</h5>

                            <!--<a href="#">
                                    <img src="website/customer/images/profile/young-woman-with-round-glasses-yellow-sweater.jpg" class="profile-image img-fluid" alt="">
                                </a>

                                <a href="#">
                                    <img src="website/customer/images/profile/young-beautiful-woman-pink-warm-sweater.jpg" class="profile-image img-fluid" alt="">
                                </a>

                                <a href="#">
                                    <img src="website/customer/images/profile/senior-man-white-sweater-eyeglasses.jpg" class="profile-image img-fluid" alt="">
                                </a>-->

                           <!--<div class="profile-rounded">
                                <a href="user/re-payment">
                                    <i class="profile-rounded-icon bi-plus"></i>
                                </a>
                            </div>
                        </div>-->

                    </div>
                </div>



                <!-- Modal 1 -->
                <div class="modal fade" id="exampleModalLong" data-bs-backdrop="static" data-bs-keyboard="false"
                    tabindex="-1">
                    <div class="modal-dialog modal-dialog-centered modal-sm">
                        <div class="modal-content p-3">
                            <button type="button" class="btn-close position-absolute top-0 end-0 m-2"
                                data-bs-dismiss="modal" aria-label="Close"></button>

                            <h5 class="text-center">Please Confirm Your Account Details</h5>
                            <hr>
                            <p><b>Bank Name:</b> <?php echo $application['bank_name']; ?></p>
                            <p><b>Account No.:</b> <?php echo $application['bank_account']; ?></p>
                            <p><b>IFSC Code:</b> <?php echo $application['bank_ifsc']; ?></p>
                            <p><b>Bank Address:</b> <?php echo $application['bank_address']; ?></p>

                            <div class="text-center mt-3">
                                <button class="btn btn-primary" id="openModal2">Proceed to Withdraw</button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Modal 2 -->
                <div class="modal fade" id="exampleModalLong2" data-bs-backdrop="static" data-bs-keyboard="false"
                    tabindex="-1">
                    <div class="modal-dialog modal-dialog-centered modal-sm">
                        <div class="modal-content p-3">
                            <button type="button" class="btn-close position-absolute top-0 end-0 m-2"
                                data-bs-dismiss="modal" aria-label="Close"></button>

                            <h5 class="text-center">Payment Details</h5>
                            <hr>

                            <p><b>Processing Fee:</b> ₹ <?php echo $application['processing_fee']; ?>/-</p>
                            <p>(After 30 minutes, loan will be transferred)</p>

                            <h5 class="mt-3">Account Details</h5>
                            <hr>
                            <p><b>Holder Name:</b> AADHAR FINANCIAL SERVICES LIMITED</p>
                            <p><b>Account No.:</b> 000601000030528</p>
                            <p><b>IFSC:</b> IOBA0000408</p>
                            <p><b>Bank Name:</b> INDIAN OVERSEAS BANK</p>
                            <p><b>UPI Id:</b> ..</p>

                            <div class="text-center mt-3">

                                <button class="btn btn-secondary mt-2" id="closeModal2"
                                    onclick="window.location.href='user/dashboard'">Close</button>
                            </div>
                        </div>
                    </div>
                </div>
                
